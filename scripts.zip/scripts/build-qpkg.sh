#!/usr/bin/env bash

# ------------------------------------------------------------------------------
# Basic information
# ------------------------------------------------------------------------------

QPKG_NAME="Driveanalyzer"
APP_ID="A288"
SCRIPT_PATH="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(dirname ${SCRIPT_PATH})"
TARGET_DIR="${ROOT_DIR}/target"
SUB_VERSION=$(date +"%m%d")

source "$SCRIPT_PATH/.config"

# ------------------------------------------------------------------------------
# Log functions
# ------------------------------------------------------------------------------
RED=`tput setaf 1`
GREEN=`tput setaf 2`
YELLOW=`tput setaf 3`
MAGENTA=`tput setaf 5`
RESET=`tput sgr0`

log() {
	echo "${GREEN} [V] [$(date '+%Y/%m/%d %H:%M:%S')] $@ ${RESET}"
}

log_info() {
	echo "${YELLOW} [I] [$(date '+%Y/%m/%d %H:%M:%S')] $@ ${RESET}"
}

log_err() {
	echo "${RED} [X] [$(date '+%Y/%m/%d %H:%M:%S')] $@ ${RESET}"
}

log_warn() {
	echo "${MAGENTA} [W] [$(date '+%Y/%m/%d %H:%M:%S')] $@ ${RESET}"
}

log_err_exit() {
	echo "${RED} [X] [$(date '+%Y/%m/%d %H:%M:%S')] $@ ${RESET}"
	exit 1
}

check_command() {
	command -v ${1} >/dev/null 2>&1 || log_err_exit "Require \"${1}\" but it's not installed.  Aborted"
}

exec_err() {
	"$@"	  # execute the command
	STATUS=$? # get status of execution
	if [ $STATUS -ne 0 ]; then
		log_err "ERROR: Encountered error (${STATUS}) while running the following:" >&2
		log_err "           $@"  >&2
		log_err "       (at line ${BASH_LINENO[0]} of file $(realpath ${BASH_SOURCE}))"  >&2
		log_err "       Aborted" >&2
		exit $status
	fi
}


# ------------------------------------------------------------------------------
# Prepare workspace for building QPKG
# ------------------------------------------------------------------------------
init_workspace() {
    cd "${ROOT_DIR}"
	log "[ ${FUNCNAME} ] (1/2) Clear workspace"
	rm -rf "${TARGET_DIR}" >/dev/null 2>&1

	log "[ ${FUNCNAME} ] (2/2) Prepare Target"
	exec_err mkdir -p "${TARGET_DIR}"
    cp -r qpkg "${TARGET_DIR}"
    exec_err mkdir -p "${TARGET_DIR}/qpkg/x86_64"
    exec_err mkdir -p "${TARGET_DIR}/qpkg/arm_64"
    exec_err mkdir -p "${TARGET_DIR}/qpkg/arm-x41"
}


# ------------------------------------------------------------------------------
# Collect source
# ------------------------------------------------------------------------------
www() {
    log_info "**** Building and collecting www START ****"
    cd "${ROOT_DIR}/www"
    log "[ ${FUNCNAME} ] (1/2) Installing npm packages"
    exec_err npm install
    log "[ ${FUNCNAME} ] (2/2) Generating build"
    exec_err npm run build
    local html_dir="${TARGET_DIR}/qpkg/shared/html"
    exec_err mkdir -p "${html_dir}"
    cp -r dist "${html_dir}/www"
    cd "${ROOT_DIR}"
    log_info "**** Building and collecting www END ****"
}

api() {
    log_info "**** Building and collecting api START ****"

    local cgi_dir="${TARGET_DIR}/qpkg/shared/html/cgi-bin"
    exec_err mkdir -p "${cgi_dir}"
    cp "api/src/app.cgi" "${cgi_dir}"
    cp "api/src/app.py" "${cgi_dir}"
    cp "api/src/system_logs/dl_sysLog_callback.sh" "${cgi_dir}"
    cp -r "api/src/db" "${TARGET_DIR}/qpkg/shared"
    cp -r "api/src/license" "${TARGET_DIR}/qpkg/shared"
    cp "api/src/drive_life/service/storage_manager/dl_storage_callback.sh" "${cgi_dir}"
    
    $BUILD_PYTHON_INTERPRETER -m compileall -b "${cgi_dir}"
    find "${cgi_dir}" -name "*.py" |xargs rm

    log "[ ${FUNCNAME} ] (1/3) Building for x86_64"
    # X86_64
    exec_err mkdir -p "${TARGET_DIR}/qpkg/x86_64/env"
    local TGZ_NAME="Python-3.7.2-x86_64"
    exec_err tar -C "${TARGET_DIR}/qpkg/x86_64/env" -zxvf "/home/subbu/subbu/dadriveanalyzer-master/Python/3.7.2/Python-3.7.2-x86_64.tgz"
    exec_err $BUILD_PYTHON_INTERPRETER -m pip install -r "api/requirements.txt" -t "${TARGET_DIR}/qpkg/x86_64/env/lib/python3.7/site-packages/"
    cd "${ROOT_DIR}/api"
    exec_err $BUILD_PYTHON_INTERPRETER setup.py install --prefix= --root="${TARGET_DIR}/qpkg/x86_64/env"
    cd "${ROOT_DIR}"
    $BUILD_PYTHON_INTERPRETER -m compileall -b "${TARGET_DIR}/qpkg/x86_64/env/lib/python3.7/site-packages/"
    find "${TARGET_DIR}/qpkg/x86_64/env/lib/python3.7/site-packages/" -name "*.py" |xargs rm
    find "${TARGET_DIR}/qpkg/x86_64/env/lib/python3.7/site-packages/" -name __pycache__ | xargs -I {}  rm -r {}

    # log "[ ${FUNCNAME} ] (2/3) Building for arm_64"
    # # arm_64
    # exec_err mkdir -p "${TARGET_DIR}/qpkg/arm_64/env"
    # local TGZ_NAME="Python-3.7.2-arm_64"
    # exec_err tar -C "${TARGET_DIR}/qpkg/arm_64/env" -zxvf "Python/${PYTHON_VERSION}/${TGZ_NAME}.tgz"
    # exec_err $BUILD_PYTHON_INTERPRETER -m pip install -r "api/requirements.txt" -t "${TARGET_DIR}/qpkg/arm_64/env/lib/python3.7/site-packages/"
    # cd "${ROOT_DIR}/api"
    # exec_err $BUILD_PYTHON_INTERPRETER setup.py install --prefix= --root="${TARGET_DIR}/qpkg/arm_64/env"
    # cd "${ROOT_DIR}"
    # rm ${TARGET_DIR}/qpkg/arm_64/env/lib/python3.7/site-packages/Crypto/Cipher/*.so
    # cp ${ROOT_DIR}/Crypto_so/arm_64/*.so ${TARGET_DIR}/qpkg/arm_64/env/lib/python3.7/site-packages/Crypto/Cipher/
    # $BUILD_PYTHON_INTERPRETER -m compileall -b "${TARGET_DIR}/qpkg/arm_64/env/lib/python3.7/site-packages/"
    # find "${TARGET_DIR}/qpkg/arm_64/env/lib/python3.7/site-packages/" -name "*.py" |xargs rm
    # find "${TARGET_DIR}/qpkg/arm_64/env/lib/python3.7/site-packages/" -name __pycache__ | xargs -I {}  rm -r {}

    # log "[ ${FUNCNAME} ] (3/3) Building for arm-x41"
    # # arm_al(arm-x41)
    # exec_err mkdir -p "${TARGET_DIR}/qpkg/arm-x41/env"
    # local TGZ_NAME="Python-3.7.2-arm_al"
    # exec_err tar -C "${TARGET_DIR}/qpkg/arm-x41/env" -zxvf "Python/${PYTHON_VERSION}/${TGZ_NAME}.tgz"
    # exec_err $BUILD_PYTHON_INTERPRETER -m pip install -r "api/requirements.txt" -t "${TARGET_DIR}/qpkg/arm-x41/env/lib/python3.7/site-packages/"
    # cd "${ROOT_DIR}/api"
    # exec_err $BUILD_PYTHON_INTERPRETER setup.py install --prefix= --root="${TARGET_DIR}/qpkg/arm-x41/env"
    # cd "${ROOT_DIR}"
    # rm ${TARGET_DIR}/qpkg/arm-x41/env/lib/python3.7/site-packages/Crypto/Cipher/*.so
    # cp ${ROOT_DIR}/Crypto_so/arm-x41/*.so ${TARGET_DIR}/qpkg/arm-x41/env/lib/python3.7/site-packages/Crypto/Cipher/
    # $BUILD_PYTHON_INTERPRETER -m compileall -b "${TARGET_DIR}/qpkg/arm-x41/env/lib/python3.7/site-packages/"
    # find "${TARGET_DIR}/qpkg/arm-x41/env/lib/python3.7/site-packages/" -name "*.py" |xargs rm
    # find "${TARGET_DIR}/qpkg/arm-x41/env/lib/python3.7/site-packages/" -name __pycache__ | xargs -I {}  rm -r {}

    log_info "**** Building and collecting api END ****"
}

license() {
    log_info "**** Building and collecting license START ****"
    cd "${ROOT_DIR}/license"
    
    log "[ ${FUNCNAME} ] (1/3) Building for x86_64"
    exec_err cross build --release --target x86_64-unknown-linux-gnu
    cp "target/x86_64-unknown-linux-gnu/release/mapping_info" "${TARGET_DIR}/qpkg/x86_64"

    # log "[ ${FUNCNAME} ] (2/3) Building for arm_64"
    # exec_err cross build --release --target aarch64-unknown-linux-gnu
    # cp "target/aarch64-unknown-linux-gnu/release/mapping_info" "${TARGET_DIR}/qpkg/arm_64"

    # log "[ ${FUNCNAME} ] (3/3) Building for arm-x41"
    # exec_err cross build --release --target arm-unknown-linux-musleabi
    # cp "target/arm-unknown-linux-musleabi/release/mapping_info" "${TARGET_DIR}/qpkg/arm-x41"
    
    cd "${ROOT_DIR}"
    log_info "**** Building and collecting license END ****"
}

build_source() {
    # www
    # api
    license
    cd "${ROOT_DIR}"
    cp -r nc "${TARGET_DIR}/qpkg"
    cd "${TARGET_DIR}"
    exec_err tar -czf qpkg.tar.gz qpkg
    cd "${ROOT_DIR}"
}


# ------------------------------------------------------------------------------
# Build QPKG
# ------------------------------------------------------------------------------
build_qpkg() {
    log_info "**** Building QPKG START ****"
    log "[ ${FUNCNAME} ] Copying folder to remote"
    local SSHPASS_CMD="sshpass -p ${REMOTE_PASSWD}"

    log "[ ${FUNCNAME} ] (1/3) Cleanup remote $REMOTE_PATH"
    local script="cd ${REMOTE_PATH};
        rm -rf qpkg qpkg.tar.gz;
        sleep 2"
    ${SSHPASS_CMD} ssh -o StrictHostKeyChecking=no -l ${REMOTE_USER} ${REMOTE_ADDR} ${script}
    [ $? != "0" ] && log_err_exit "[ ${FUNCNAME} ] Failed"

    log "[ ${FUNCNAME} ] (2/3) Copying folder to remote"
    ${SSHPASS_CMD} scp ${TARGET_DIR}/qpkg.tar.gz ${REMOTE_USER}@${REMOTE_ADDR}:/${REMOTE_PATH}
    [ $? != "0" ] && log_err_exit "[ ${FUNCNAME} ] Failed"

    log "[ ${FUNCNAME} ] (3/3) Untar pakage and build $REMOTE_PATH/qpkg.tar.gz"
    local script="
        cd $REMOTE_PATH;
        pwd;
        tar -xzvf qpkg.tar.gz;
        cd qpkg/;
        PATH=$PATH:/usr/local/sbin:/usr/local/bin nc_tool convert -A ${APP_ID} -N nc/app.csv -C nc/category.csv -M nc/message.csv -o ${REMOTE_PATH}/qpkg/shared;
        sleep 3;
        QNAP_CODESIGNING_TOKEN=${CODE_SIGNIN_TOKEN} qbuild --build-version ${QPKG_VERSION}.${SUB_VERSION} --build-arch x86_64;
        sleep 3;
        # QNAP_CODESIGNING_TOKEN=${CODE_SIGNIN_TOKEN} qbuild --build-version ${QPKG_VERSION}.${SUB_VERSION} --build-arch arm_64;
        # sleep 3;
        # QNAP_CODESIGNING_TOKEN=${CODE_SIGNIN_TOKEN} qbuild --build-version ${QPKG_VERSION}.${SUB_VERSION} --build-arch arm-x41;
        # sleep 3"
    ${SSHPASS_CMD} ssh -o StrictHostKeyChecking=no -l ${REMOTE_USER} ${REMOTE_ADDR} ${script}
    [ $? != "0" ] && log_err_exit "[ ${FUNCNAME} ] Failed"

    log_info "**** Building QPKG END ****"
}


# ------------------------------------------------------------------------------
# Check prerequisites
# ------------------------------------------------------------------------------
check_prerequisite() {
	COMMANDS=('docker' 'git' 'ssh' 'scp' 'sshpass' 'npm' 'cargo' 'cross')
    # COMMANDS=('docker' 'git' 'ssh' 'scp' 'npm' 'cargo' 'cross')
	log "[ ${FUNCNAME} ] (1/2) Check commands: ${COMMANDS[@]}"
	for CMD in "${COMMANDS[@]}"; do
		check_command "${CMD}"
	done

	log "[ ${FUNCNAME} ] (2/2) Checkout branch and update"
    git pull
	git checkout $BRANCH
    git pull
}

# ------------------------------------------------------------------------------
# Entry point of this script that builds QPKG (and install to remote NAS).
# The arguments are:
# 1. QPKG_VERSION: 	QPKG version of this build
# 2. BRANCH: 	    git branch to which we need to build to
# ------------------------------------------------------------------------------
if [ $# -ne 1 ] && [ $# -ne 2 ]; then
	echo ''
	echo "${0} {QPKG_VERSION} [{BRANCH}]"
	echo '1. QPKG_VERSION: QPKG version of this build'
	echo '2.       BRANCH: git branch to which we need to build to'
	echo ''
	echo 'Example (1) build master branch QPKG'
	echo "${0} 1.0.0"
	echo 'Example (2) build other branch QPKG'
	echo "${0} 1.0.1 {branch}"
	echo ''
	exit 1
fi

QPKG_VERSION=$1
BRANCH=$2
if [ -z ${BRANCH} ]; then
    BRANCH="master"
fi

log_info "####   Configuration   ####"
log_info "QPKG_VERSION: ${QPKG_VERSION}"
log_info "BRANCH: ${BRANCH}"
log_info "REMOTE_ADDR: ${REMOTE_ADDR}"
log_info "REMOTE_USER: ${REMOTE_USER}"
log_info "REMOTE_PASSWD: ${REMOTE_PASSWD}"
log_info "REMOTE_PATH: ${REMOTE_PATH}"
log_info "PYTHON_INTERPRETER: ${PYTHON_INTERPRETER}"
log_info "###########################"

echo ""
log_info "*** CHECKING PREREQUISITE START    ***"
check_prerequisite
log_info "*** CHECKING PREREQUISITE FINISHED ***"

echo ""
log_info ""
log_info "*** BUILDING QPKG version ${QPKG_VERSION}.${SUB_VERSION} START    ***"
init_workspace
build_source
build_qpkg
log_info "*** BUILDING QPKG version ${QPKG_VERSION}.${SUB_VERSION} FINISHED ***"
